/**
 * 
 */
/**
 * @author LOLA
 *
 */
module TPO_otraForma {
	requires java.desktop;
}